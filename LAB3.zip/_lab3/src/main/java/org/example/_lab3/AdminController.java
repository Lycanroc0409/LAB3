package org.example._lab3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class AdminController {
    public AdminController(Stage stage) {
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #2a2a3b; -fx-padding: 20; -fx-alignment: center;");

        Label welcomeLabel = new Label("Admin Control");
        welcomeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold; -fx-effect: dropshadow(gaussian, black, 10, 0.5, 1, 1);");

        TableView<Admin> table = AdminDAO.getAdminTable();

        TextField nameField = new TextField();
        nameField.setStyle("-fx-background-color: #4a4a5e; -fx-text-fill: white; -fx-prompt-text-fill: #d1d1d1; -fx-font-size: 14px; -fx-border-radius: 5;");
        nameField.setPromptText("Username");

        TextField emailField = new TextField();
        emailField.setStyle("-fx-background-color: #4a4a5e; -fx-text-fill: white; -fx-prompt-text-fill: #d1d1d1; -fx-font-size: 14px; -fx-border-radius: 5;");
        emailField.setPromptText("Email");

        PasswordField passwordField = new PasswordField();
        passwordField.setStyle("-fx-background-color: #4a4a5e; -fx-text-fill: white; -fx-prompt-text-fill: #d1d1d1; -fx-font-size: 14px; -fx-border-radius: 5;");
        passwordField.setPromptText("Password");

        Button createBtn = new Button("Create");
        Button updateBtn = new Button("Update");
        Button deleteBtn = new Button("Delete");
        Button backBtn = new Button("Back");

        // Button styling and hover effects
        createBtn.setStyle("-fx-background-color: #5c6bc0; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;");
        createBtn.setOnMouseEntered(e -> createBtn.setStyle("-fx-background-color: #3f51b5; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        createBtn.setOnMouseExited(e -> createBtn.setStyle("-fx-background-color: #5c6bc0; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        updateBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;");
        updateBtn.setOnMouseEntered(e -> updateBtn.setStyle("-fx-background-color: #d32f2f; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        updateBtn.setOnMouseExited(e -> updateBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        deleteBtn.setStyle("-fx-background-color: #d32f2f; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;");
        deleteBtn.setOnMouseEntered(e -> deleteBtn.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        deleteBtn.setOnMouseExited(e -> deleteBtn.setStyle("-fx-background-color: #d32f2f; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        backBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;");
        backBtn.setOnMouseEntered(e -> backBtn.setStyle("-fx-background-color: #455a64; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        backBtn.setOnMouseExited(e -> backBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        // Action events
        createBtn.setOnAction(e -> {
            AdminDAO.createAdmin(nameField.getText(), emailField.getText(), passwordField.getText());
            table.setItems(AdminDAO.getAllAdmins());
        });

        updateBtn.setOnAction(e -> {
            Admin selected = table.getSelectionModel().getSelectedItem();
            AdminDAO.updateAdmin(selected.getId(), nameField.getText(), emailField.getText());
            table.setItems(AdminDAO.getAllAdmins());
        });

        deleteBtn.setOnAction(e -> {
            AdminDAO.deleteAdmin(table.getSelectionModel().getSelectedItem().getId());
            table.setItems(AdminDAO.getAllAdmins());
        });

        backBtn.setOnAction(e -> new DashboardController(stage, "Admin"));

        layout.getChildren().addAll(welcomeLabel, table, new Label("Name"), nameField, new Label("Email"), emailField, new Label("Password"), passwordField, createBtn, updateBtn, deleteBtn, backBtn);

        // Adding fade animation
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), layout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        stage.setScene(new Scene(layout, 600, 600));
        stage.setTitle("Admin Control");
        stage.show();
    }
}
