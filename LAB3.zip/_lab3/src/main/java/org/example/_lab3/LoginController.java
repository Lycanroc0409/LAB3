package org.example._lab3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class LoginController {
    public LoginController(Stage stage) {
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #1e2a47; -fx-padding: 30; -fx-alignment: center;");

        // Title
        Label titleLabel = new Label("Login");
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 30px; -fx-font-weight: bold; -fx-effect: dropshadow(gaussian, black, 10, 0.5, 1, 1);");

        // Username and Password fields
        TextField emailField = new TextField();
        emailField.setStyle("-fx-background-color: #2a3d57; -fx-text-fill: white; -fx-prompt-text-fill: #a2b5d7; -fx-font-size: 14px; -fx-border-radius: 5;");
        emailField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setStyle("-fx-background-color: #2a3d57; -fx-text-fill: white; -fx-prompt-text-fill: #a2b5d7; -fx-font-size: 14px; -fx-border-radius: 5;");
        passwordField.setPromptText("Password");

        // Login Button
        Button loginBtn = new Button("Login");
        loginBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;");
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle("-fx-background-color: #455a64; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        loginBtn.setOnAction(e -> {
            if (LoginDAO.validateLogin(emailField.getText(), passwordField.getText())) {
                new DashboardController(stage, emailField.getText());
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Credentials!");
                alert.show();
            }
        });

        // Adding components to the layout
        layout.getChildren().addAll(titleLabel, new Label("Email"), emailField, new Label("Password"), passwordField, loginBtn);

        // Adding fade-in animation
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), layout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        stage.setScene(new Scene(layout, 400, 400));
        stage.setTitle("Login");
        stage.show();
    }
}
