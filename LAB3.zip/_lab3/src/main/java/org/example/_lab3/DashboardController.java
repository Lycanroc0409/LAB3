package org.example._lab3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class DashboardController {
    public DashboardController(Stage stage, String username) {
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 30; -fx-alignment: center;");

        // Title
        Label welcomeLabel = new Label("Welcome, " + username);
        welcomeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 30px; -fx-font-weight: bold; -fx-effect: dropshadow(gaussian, black, 10, 0.5, 1, 1);");

        // Buttons
        Button adminBtn = new Button("Admin");
        Button employeeBtn = new Button("Employee");
        Button logoutBtn = new Button("Logout");
        Button exitBtn = new Button("Exit");

        // Button Styles
        adminBtn.setStyle("-fx-background-color: #4c4f69; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;");
        employeeBtn.setStyle("-fx-background-color: #4c4f69; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;");
        logoutBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;");
        exitBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;");

        // Hover Effects
        adminBtn.setOnMouseEntered(e -> adminBtn.setStyle("-fx-background-color: #3e4350; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        adminBtn.setOnMouseExited(e -> adminBtn.setStyle("-fx-background-color: #4c4f69; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        employeeBtn.setOnMouseEntered(e -> employeeBtn.setStyle("-fx-background-color: #3e4350; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        employeeBtn.setOnMouseExited(e -> employeeBtn.setStyle("-fx-background-color: #4c4f69; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        logoutBtn.setOnMouseEntered(e -> logoutBtn.setStyle("-fx-background-color: #455a64; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        logoutBtn.setOnMouseExited(e -> logoutBtn.setStyle("-fx-background-color: #607d8b; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        exitBtn.setOnMouseEntered(e -> exitBtn.setStyle("-fx-background-color: #d32f2f; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));
        exitBtn.setOnMouseExited(e -> exitBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10 20; -fx-border-radius: 5;"));

        // Button Actions
        adminBtn.setOnAction(e -> new AdminController(stage));
        employeeBtn.setOnAction(e -> new EmployeeController(stage));
        logoutBtn.setOnAction(e -> new LoginController(stage));
        exitBtn.setOnAction(e -> stage.close());

        // Adding components to the layout
        layout.getChildren().addAll(welcomeLabel, adminBtn, employeeBtn, logoutBtn, exitBtn);

        // Adding fade-in animation
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), layout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        stage.setScene(new Scene(layout, 500, 500));
        stage.setTitle("Dashboard");
        stage.show();
    }
}
