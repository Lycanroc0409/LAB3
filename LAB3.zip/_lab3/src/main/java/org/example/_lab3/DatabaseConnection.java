package org.example._lab3;


import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/hrmanagement",
                    "root", "root@roots");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Database Connection Failed!");
        }
    }
}

