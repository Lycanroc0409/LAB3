module org.example._lab3 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires junit;
    requires org.testng;

    opens org.example._lab3 to javafx.fxml;
    exports org.example._lab3;
}