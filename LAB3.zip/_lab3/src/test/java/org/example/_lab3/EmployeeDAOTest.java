package org.example._lab3;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;




public class EmployeeDAOTest {

    @Test
    public void testCalculateYearlySalary() {
        Employee emp = new Employee(1, "John Doe", "Developer", 5000.0);
        double yearlySalary = EmployeeDAO.calculateYearlySalary(emp);

        assertEquals(60000.0, yearlySalary, "Yearly salary should be correctly calculated");
    }

    @Test
    public void testCalculateYearlySalaryForZeroSalary() {
        Employee emp = new Employee(2, "Jane Doe", "Intern", 0.0);
        double yearlySalary = EmployeeDAO.calculateYearlySalary(emp);

        assertEquals(0.0, yearlySalary, "Yearly salary should be zero if monthly salary is zero");
    }
}
